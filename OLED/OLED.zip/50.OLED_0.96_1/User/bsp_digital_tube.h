#ifndef __BSP_DIGITAL_TUBE_H__
#define __BSP_DIGITAL_TUBE_H__

#include <stm32f10x.h>

extern unsigned int num[];

void Digital_Tube_Configuration(void);

#endif
