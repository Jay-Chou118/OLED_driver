#ifndef __BSP_EXTI_H__
#define __BSP_EXTI_H__

#include <stm32f10x.h>

void PA0_EXTI0_Configuration(void);
void PA5_EXTI5_Configuration(void);

#endif
